//My name is Nava Hurwitz. This is a program that converts from feet, inches, miles, or yards into Smoots. Smoots is the unit of measurement used to measure the length of the Mass Ave Bridge in Boston. There is also a fun little bonus activity at the end.
//I included two new things in my code. Switch, case statements and a Java dictionary. I used a switch, case statement instead of the outer if statements. I used a Java dictionary in the bonus activity at the end to store the names of different bridges and their lengths in Smoots

//imports the java scanner object 
import java.util.Scanner; 
//imports the java dictionary class 
import java.util.Hashtable; 
import java.util.Dictionary; 

public class MyProgram
{
    public static void main(String[] args)
    {
        //print statements that introduce the program 
        System.out.println("This is a program that will convert units of measurement into Smoots!");
        System.out.println("A Smoot is a unit of measurement created as the result of an MIT student prank and they are used to measure the Mass Ave Bridge in Boston");
        
        //total number of smoots of the Mass Ave Bridge in Boston (real and approximation) 
        String massAveBridgeRealSmootsNumber = "364.4 Smoots and One Ear"; 
        double massAveBridgeTotalSmootsApprox = 364.4;
        
        //opens and new scanner object 
        Scanner number = new Scanner(System.in);
        
        //asks the user to enter a number and stores that number in an int variable 
        System.out.println("Pick a number, any number");
        int numberOfChoice = number.nextInt(); 
        
        //an array of strings that stores measurement options 
        String[] normalUnitsOfMeasurement = {"Feet", "Inches", "Miles", "Yards"};
        
        //asks the user to pick a number between one and three and stores their choice in a variable called indexOfChoice
        System.out.println("Pick a number between 0 and 3");
        int indexOfChoice = number.nextInt(); 

        //use a switch case to test the different user inputs 
        //it tests with the variable indexOfChoice 
        switch(indexOfChoice){
            //first case
            //runs if indexOfChoice is equal to zero 
            case 0:
                System.out.println("You chose to convert from feet to smoots");
                
                //conversion factor 
                double feetToSmoots = numberOfChoice / 5.58333333;
                
                //assigns the statement to be printed of how many smoots your number of feet is and prints it to the console
                String totalSmootsForFeet = numberOfChoice + " feet is equal to " + String.format("%.4f", feetToSmoots) + " number of smoots."; 
                System.out.println(totalSmootsForFeet); 
                
                //how far off is your total num of smoots from that of the Mass Ave Bridge
                System.out.println("Now you will see how many smoots off your total is from the length of the Mass Ave Bridge");
                
                //length difference 
                double lengthDifferenceForFeet = massAveBridgeTotalSmootsApprox - feetToSmoots;
                
                //conditionals to check if your total is less than, greater than, or equal to the length of the Mass Ave Bridge
                if (lengthDifferenceForFeet > 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForFeet) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is less than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForFeet < 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForFeet) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is more than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForFeet == 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForFeet) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is the same as the total of the bridge");
                    break; 
                }
                //breaks out of the first case and moves on to the second if not met
                break;
            //second case 
            //runs if indexOfChoice is equal to one 
            case 1:
                System.out.println("You chose to convert from inches to smoots");
                
                //conversion factor 
                double inchesToSmoots = numberOfChoice / 67;
               
                //assigns the statement to be printed of how many smoots your number of inches is and prints it to the console
                String totalSmootsForInches = numberOfChoice + " inches is equal to " + String.format("%.4f", inchesToSmoots) + " number of smoots.";
                System.out.println(totalSmootsForInches);
                    
                //how far off is your total num of smoots from that of the Mass Ave Bridge
                System.out.println("Now you will see how many smoots off your total is from the length of the Mass Ave Bridge");
                
                //length difference 
                double lengthDifferenceForInches = massAveBridgeTotalSmootsApprox - inchesToSmoots;
                
                //conditionals to check if your total is less than, greater than, or equal to the length of the Mass Ave Bridge
                if (lengthDifferenceForInches > 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForInches) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is less than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForInches < 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForInches) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is more than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForInches == 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForInches) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is the same as the total of the bridge");
                    break; 
                }
                //breaks out of the first case and moves on to the second if not met
                break; 
            //third case 
            //runs if indexOfChoice is equal to two 
            case 2:
                System.out.println("You chose to convert from miles to smoots");
               
                //conversion factor 
                double milesToSmoots = numberOfChoice * 945.671642;
                
                //assigns the statement to be printed of how many smoots your number of miles is and prints it to the console
                String totalSmootsForMiles = numberOfChoice + " miles is equal to " + String.format("%.4f", milesToSmoots) + " number of smoots.";
                System.out.println(totalSmootsForMiles);
                    
                //how far off is your total num of smoots from that of the Mass Ave Bridge
                System.out.println("Now you will see how many smoots off your total is from the length of the Mass Ave Bridge");
                
                //length difference 
                double lengthDifferenceForMiles = massAveBridgeTotalSmootsApprox - milesToSmoots;
                
                //conditionals to check if your total is less than, greater than, or equal to the length of the Mass Ave Bridge
                if (lengthDifferenceForMiles > 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForMiles) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is less than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForMiles < 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForMiles) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is more than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForMiles == 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForMiles) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is the same as the total of the bridge");
                    break; 
                }
                //breaks out of the first case and moves on to the second if not met
                break;
            //fourth case 
            //runs if indexOfChoice is equal to three 
            case 3:
                System.out.println("You chose to convert yards to smoots");
                
                //conversion factor 
                double yardsToSmoots = numberOfChoice / 1.86111111;
                
                //assigns the statement to be printed of how many smoots your number of yards is and prints it to the console
                String totalSmootsForYards = numberOfChoice + " yards is equal to " + String.format("%.4f", yardsToSmoots) + " number of smoots.";
                System.out.println(totalSmootsForYards);
                    
                //how far off is your total num of smoots from that of the Mass Ave Bridge
                System.out.println("Now you will see how many smoots off your total is from the length of the Mass Ave Bridge");
                
                //length difference 
                double lengthDifferenceForYards = massAveBridgeTotalSmootsApprox - yardsToSmoots;
                
                //conditionals to check if your total is less than, greater than, or equal to the length of the Mass Ave Bridge
                if (lengthDifferenceForYards > 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForYards) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is less than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForYards < 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForYards) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is more than total of the bridge");
                    break; 
                }
                if (lengthDifferenceForYards == 0) {
                    String difference = "Your total number of smoots is a " + String.format("%.4f", lengthDifferenceForYards) + " smoot difference in length";
                    System.out.println(difference); 
                    System.out.println("Your smoots total is the same as the total of the bridge");
                    break; 
                }
                //breaks out of the first case and moves on to the second if not met
                break;
        } 
        
        //intro statements for a fun bonus activity 
        System.out.println("Here is a fun bonus activity!");
        System.out.println("You get to see how Smoots long some other bridges are!"); 
        
        //creates a new dictionary where both the keys and values are strings 
        Dictionary<String, String> bridgeLengths = new Hashtable<>(); 
        
        //puts 5 different key,value pairs into the dictionary 
        bridgeLengths.put("Golden Gate Bridge", "1608.537 Smoots");
        bridgeLengths.put("George Washington Bridge", "852.5373 Smoots");
        bridgeLengths.put("Verrazano Narrows Bridge", "2453.7313 Smoots");
        bridgeLengths.put("Seven Mile Bridge", "6397.6119 Smoots");
        bridgeLengths.put("Brooklyn Bridge", "1077.493 Smoots");
        
        //adds a new line with the scanner to make sure that it stops the previous input and allows the next input to work
        number.nextLine(); 
        
        //user input with scanner 
        //gives the user the options for input and stores it in a variable called bridgeOfChoice
        System.out.println("Here are your bridge options, choose one: Golden Gate Bridge, George Washington Bridge, Verrazano Narrows Bridge, Seven Mile Bridge, Brooklyn Bridge");
        String bridgeOfChoice = number.nextLine();
        
        //uses the .get() to retrieve the value of a specified key
        //turns the object into a string using the (String) function 
        String bridgeChoiceInSmoots = (String) bridgeLengths.get(bridgeOfChoice); 
        
        //prints a sentence telling you the length of your specified bridge in smoots
        System.out.println("The length of " + bridgeOfChoice + " in smoots is " + bridgeChoiceInSmoots); 
        
        //closes the scanner to allow the scanner to work properly 
        number.close(); 
    } 
}